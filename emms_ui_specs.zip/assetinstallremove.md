# Asset Install / Remove

## 1. Page Purpose

The notebook describes an **Asset Install/Remove** page for recording installation or removal of an asset/component. It reuses shared fields through Asset Description, shows an Asset Install/Remove list, supports adding a line, and contains separate installation/removal details.

## 2. Overall Layout

Top-to-bottom:

1. Asset Install/Remove heading.
2. Shared fields through Asset Description.
3. Add Line action.
4. Asset Install/Remove list.
5. List fields and actions.
6. Install/Remove/Delete actions.
7. A note says to select and fetch PM Detail.
8. Add-line form with Job Type selection.
9. Installation/removal-specific fields.
10. Save action.

The Job Type area explicitly shows two options:
- Install/Remove
- Remove

The handwritten layout suggests conditional fields based on job type.

## 3. Page Hierarchy

```text
Asset Install/Remove
├── Shared Fields
│   └── Same fields till Asset Description
├── Add Line
├── Asset Install/Remove List
│   ├── Job Type
│   ├── Item
│   ├── LCN
│   ├── Build Item
│   ├── Asset No.
│   ├── Position
│   ├── CM Item
│   ├── Update DateTime
│   ├── Install/Remove By
│   ├── Created By
│   ├── Status
│   └── Action
│       ├── Install/Remove
│       └── Delete
├── Select & Fetch PM Detail
└── Add Line Form
    ├── Job Type
    │   ├── Install
    │   └── Remove
    ├── Build Item
    ├── Asset
    ├── Install date
    ├── Part No.
    ├── LCN
    ├── Remarks
    ├── Serial Num
    ├── Installed By
    ├── Installed Asset Condition
    ├── Remove Reason
    ├── Remove Condition
    ├── Position
    ├── Remove By
    ├── Item
    ├── Remove date
    └── Save
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Asset Install/Remove | heading | Asset Install/Remove | Top | No | Page title |
| 2 | Shared fields | form group | Same field till asset description | Below heading | Varies | Reused common fields |
| 3 | Add Line | action | Add Line | Near list/form boundary | No | Explicit |
| 4 | Asset Install/Remove List | table/list | Asset Install/Remove List | Below shared fields | Yes | Main record list |
| 5 | Job Type | table column | Job Type | First | Not specified | |
| 6 | Item | table column | Item | Second | Not specified | |
| 7 | LCN | table column | LCN | Third | Not specified | |
| 8 | Build Item | table column | Build Item | Fourth | Not specified | |
| 9 | Asset No. | table column | Asset No. | Fifth | Not specified | |
| 10 | Position | table column | Position | Sixth | Not specified | |
| 11 | CM Item | table column | CM Item | Seventh | Not specified | |
| 12 | Update DateTime | table column | Update DateTime | Eighth | Not specified | |
| 13 | Install/Remove By | table column | Install/Remove By | Ninth | Not specified | |
| 14 | Created By | table column | Created By | Tenth | Not specified | |
| 15 | Status | table column | Status | Eleventh | Not specified | |
| 16 | Action | table column/action | Action | Final | Yes | Install/Remove and Delete |
| 17 | Install/Remove | action | Install/Remove | Action column | Yes | Explicit |
| 18 | Delete | action | Delete | Action column | Yes | Explicit |
| 19 | Select & Fetch PM Detail | action/annotation | select & Fetch PM Detail | Near add-line area | Yes | Exact control not drawn |
| 20 | Job Type | selector | Job Type | Add-line form | Yes | Conditional behavior implied |
| 21 | Install | option | Install | Job Type options | Yes | Explicit |
| 22 | Remove | option | Remove | Job Type options | Yes | Explicit |
| 23 | Build Item | input | Build Item | Add-line form | Yes | |
| 24 | Asset | input/selection | Asset | Add-line form | Yes | |
| 25 | Install date | date | Install date | Add-line form | Yes | |
| 26 | Part No. | input | Part No. | Add-line form | Yes | |
| 27 | LCN | input | LCN | Add-line form | Yes | |
| 28 | Remarks | input/text | Remarks | Add-line form | Yes | |
| 29 | Serial Num | input | Serial Num | Add-line form | Yes | |
| 30 | Installed By | input | Installed By | Add-line form | Yes | |
| 31 | Installed Asset Condition | input | Installed Asset Condition | Add-line form | Yes | |
| 32 | Remove Reason | input | Remove Reason | Removal-related area | Yes | |
| 33 | Remove Condition | input | Remove Condition | Removal-related area | Yes | |
| 34 | Position | input | Position | Add-line form | Yes | |
| 35 | Remove By | input | Remove By | Removal-related area | Yes | |
| 36 | Item | input | Item | Add-line form | Yes | |
| 37 | Remove date | date | Remove date | Removal-related area | Yes | |
| 38 | Save | action | Save | End of form | No | Explicit |

## 5. Exact Field Details

### Job Type

- Label: Job Type
- Type: Selector
- Position: Add-line form
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Install; Remove
- Validation: Not specified
- Related controls: Install-specific and Remove-specific fields
- Notes: The drawing uses a bracket/arrow to show Job Type choices. Conditional display is [INFERRED].

### Build Item

- Label: Build Item
- Type: Input/selection
- Position: Add-line form
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Asset, Item, LCN

### Asset

- Label: Asset
- Type: Input/selection
- Position: Add-line form
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Build Item, Serial Num

### Install date

- Label: Install date
- Type: Date input
- Position: Installation-specific area
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: None
- Validation: Not specified
- Related controls: Installed By

### Remove date

- Label: Remove date
- Type: Date input
- Position: Removal-specific area
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: None
- Validation: Not specified
- Related controls: Remove By, Remove Reason, Remove Condition

### Installed Asset Condition

- Label: Installed Asset Condition
- Type: Input/selection
- Position: Installation-specific area
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Installed By, Install date

### Remove Reason / Remove Condition

- Labels: Remove Reason; Remove Condition
- Type: Input/selection
- Position: Removal-specific area
- Required: Unknown
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Remove date, Remove By

## 6. Tables / Lists

### Asset Install/Remove List

Column order:

1. Job Type
2. Item
3. LCN
4. Build Item
5. Asset No.
6. Position
7. CM Item
8. Update DateTime
9. Install/Remove By
10. Created By
11. Status
12. Action

Actions:
- Install/Remove
- Delete

The list is positioned above/near the Add Line form according to the notebook's page flow.

## 7. Navigation

Source: User View / work-order flow  
Target: Asset Install/Remove  
Trigger: Not explicitly drawn  
Relationship: Related module/function [INFERRED]  
Confidence: Medium-Low.

## 8. User Interactions

- Add Line.
- Select Job Type.
- Install.
- Remove.
- Delete.
- Select and fetch PM Detail.
- Enter installation/removal information.
- Save.

## 9. Visual/Layout Instructions

- Keep the shared fields first.
- Add Line is visibly called out near the list.
- Preserve the list column order.
- Keep Action as the final list column.
- Keep Install/Remove and Delete together as row actions.
- Keep Job Type options grouped.
- Installation-specific and removal-specific fields should remain grouped according to the notebook; do not merge them into a new structure.
- Save appears after the form fields.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Reuse shared fields through Asset Description.
- Provide an Asset Install/Remove list.
- Support Add Line.
- Include all listed columns.
- Provide Install/Remove and Delete actions.
- Provide Job Type with Install and Remove options.
- Provide installation and removal detail fields.
- Support select/fetch PM Detail.
- Provide Save.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Page title.
- Shared-field boundary.
- Add Line.
- List fields.
- List actions.
- Job Type and its two options.
- Installation/removal fields.
- Save.

### Inferred / Unclear

- Whether fields are conditionally hidden based on Job Type is implied by the grouping but not explicitly stated.
- Exact control types are not drawn.
- Exact PM-detail fetch trigger is not specified.
- `Install/Remove` may represent a combined action label rather than two separate buttons; preserve the wording.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `B34CC8B5-3574-41BC-B774-6825ACFA19B0.jpeg`

### Confidence

Overall extraction confidence:
- High

### Potential OCR/Handwriting Issues

- `LCN` and `CM Item` are preserved exactly.
- The combined `Install/Remove` wording is preserved.
