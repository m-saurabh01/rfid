# Meter Compliance

## 1. Page Purpose

The notebook describes a **Meter Compliance** page. It reuses shared work-order/asset fields through Asset Description and provides a list of meter compliance records with meter values, units, update information, and Update/Delete actions.

## 2. Overall Layout

Top-to-bottom:

1. Meter Compliance heading.
2. Shared fields through Asset Description.
3. List of meter compliance.
4. Tabular meter compliance records.
5. Update/Delete actions.
6. A note indicates dependent dropdown/input options.

## 3. Page Hierarchy

```text
Meter Compliance
├── Shared Fields
│   └── Same fields till Asset Description
├── Meter Compliance List
│   └── Table
│       ├── Asset
│       ├── Description
│       ├── Meter
│       ├── Meter Description
│       ├── UOM
│       ├── Initial Value
│       ├── Final Value
│       ├── Past Build Item [UNCLEAR]
│       ├── Updated By
│       ├── Update datetime
│       └── Action
│           ├── Update
│           └── Delete
└── Dependent dropdown / input options
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Meter Compliance | heading | Meter Compliance | Top | No | Page title |
| 2 | Shared fields | form group | Same fields till Asset Description | Below heading | Varies | Reused fields |
| 3 | List of meter compliance | table/list | List of meter compliance | Below shared fields | Yes | Main content |
| 4 | Asset | table column | Asset | First | Not specified | |
| 5 | Description | table column | Description | Second | Not specified | |
| 6 | Meter | table column | Meter | Third | Not specified | |
| 7 | Meter Description | table column | Meter Description | Fourth | Not specified | |
| 8 | UOM | table column | UOM | Fifth | Not specified | Unit of measure |
| 9 | Initial Value | table column | Initial Value | Sixth | Not specified | |
| 10 | Final Value | table column | Final Value | Seventh | Not specified | |
| 11 | Past Build Item | table column | Past Build Item [UNCLEAR] | Eighth | Not specified | Handwriting may differ |
| 12 | Updated By | table column | Updated By | Ninth | Not specified | |
| 13 | Update datetime | table column | Update datetime | Tenth | Not specified | |
| 14 | Action | table action | Action | Final | Yes | Update/Delete |
| 15 | Update | action | Update | Action column | Yes | Explicit |
| 16 | Delete | action | Delete | Action column | Yes | Explicit |
| 17 | Dependent dropdown/input options | behavior/annotation | Dependent dropdown/input options | Lower portion | Yes | Technical UI requirement |

## 5. Exact Field Details

### Shared fields

- Label: Same fields till Asset Description
- Type: Reused fields
- Position: Above meter list
- Required: Not re-specified
- Editable: Varies
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Meter list

### Meter

- Label: Meter
- Type: Table field
- Position: Third column
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Meter Description, Initial Value, Final Value
- Notes: Exact input presentation is not drawn.

### UOM

- Label: UOM
- Type: Table field
- Position: Fifth column
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Meter/value fields
- Notes: Preserve abbreviation.

### Initial Value / Final Value

- Labels: Initial Value; Final Value
- Type: Numeric/text field
- Position: Fifth/sixth and seventh table positions as visually indicated
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None shown
- Validation: Not specified
- Related controls: UOM, Meter
- Notes: Do not invent numeric validation.

## 6. Tables / Lists

### Meter Compliance List

Column order from the sketch:

1. Asset
2. Description
3. Meter
4. Meter Description
5. UOM
6. Initial Value
7. Final Value
8. Past Build Item [UNCLEAR - HANDWRITING]
9. Updated By
10. Update datetime
11. Action

Action options:
- Update
- Delete

A dependent dropdown/input-options behavior is explicitly annotated.

## 7. Navigation

Source: User View  
Target: Meter Compliance  
Trigger: Not directly listed in User View; the page is referenced from the work-order module notes.  
Relationship: Related application function  
Confidence: [INFERRED].

## 8. User Interactions

- View meter compliance records.
- Update meter compliance.
- Delete meter compliance.
- Use dependent dropdown/input options where applicable.

Do not invent additional meter calculations.

## 9. Visual/Layout Instructions

- Heading at top.
- Shared fields below heading.
- Meter list below shared fields.
- Keep the table columns in the exact written order.
- Keep Update/Delete together in the Action column.
- Preserve the dependent dropdown/input annotation as a functional UI requirement, but do not invent its dependency values.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Reuse fields through Asset Description.
- Show a meter compliance list.
- Show all listed meter-related columns.
- Provide Update and Delete actions.
- Support dependent dropdown/input options.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Page title.
- Shared-field boundary.
- Meter compliance list.
- Meter-related columns.
- Update/Delete.
- Dependent dropdown/input options.

### Inferred / Unclear

- `Past Build Item` is the most likely reading but handwriting is not completely clear.
- Exact dependent-field relationships are not specified.
- Exact edit control types are not drawn.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `8248A6F9-359B-43DA-A64E-B9E227569BCC.jpeg`

### Confidence

Overall extraction confidence:
- Medium-High

### Potential OCR/Handwriting Issues

- `Past Build Item` is uncertain.
