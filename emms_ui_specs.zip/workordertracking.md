# Work Order Tracking (CM)

## 1. Page Purpose

The notebook describes **Work Order Tracking (CM)** as a page for listing, creating, and opening work orders. Work orders can be searched/filtered and sorted. Creation is marked as role-based and available to **SEO, IC**. A work order opened from the list uses the same fields as creation, with Status explicitly editable.

## 2. Overall Layout

### List state

Top-to-bottom:

1. Page title: Work Order Tracking (CM).
2. List of WO.
3. Search / Filter.
4. Sort.
5. Create New action on the right side of the search/list controls.
6. Role-based annotation above/beside Create New.
7. Work order table.
8. Work order rows are clickable/openable.

### Create/open form state

The notebook then describes a Create WO form and an opened WO form.

Create WO:
- Title/label: Create WO
- Role annotation: SEO, IC
- Fields arranged in a compact multi-column layout.
- Some fields are marked `*`.
- An autofill/fetched-from-DB note appears below the field list.
- Cancel and Save are at the bottom.

Opened WO:
- Same fields as WO creation.
- Status is explicitly editable.

## 3. Page Hierarchy

```text
Work Order Tracking (CM)
├── List of WO
│   ├── Search / Filter
│   ├── Sort
│   ├── Create New
│   └── Work Order Table
│       └── Click/open a WO
├── Create WO
│   ├── WorkOrder [id]
│   ├── Description*
│   ├── Status*
│   ├── Asset*
│   ├── Asset Desc
│   ├── Serial #
│   ├── CM Item
│   ├── WorkType*
│   ├── PM
│   ├── PM desc
│   ├── Status Date
│   ├── Created By
│   └── Closed By
└── Opened WO
    └── Same fields as Create WO
        └── Status editable
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Work Order Tracking (CM) | heading | Work Order Tracking (CM) | Top | No | Page title |
| 2 | List of WO | section | List of WO | Below title | No | Main list |
| 3 | Search / Filter | search/filter | Search / Filter | Above table | Yes | Exact fields not specified |
| 4 | Sort | control | Sort | Near search/filter | Yes | Exact sort options not specified |
| 5 | Create New | action/button/link | Create New | Right side of list controls | No | Role-based annotation |
| 6 | Role based | annotation | Role based | Near Create New | No | Implementation/authorization note |
| 7 | WorkOrder [1] | table column | WorkOrder [1] | First table column | No | `[1]` appears to be a row/count/example marker; preserve cautiously |
| 8 | Description | table column | Description | Second column | No | List field |
| 9 | WorkType | table column | WorkType | Third column | No | List field |
| 10 | PM | table column | PM | Fourth column | No | List field |
| 11 | PM desc | table column | PM desc | Next row/column grouping | No | List field |
| 12 | Asset | table column | Asset | Next column | No | List field |
| 13 | Status Date | table column | Status Date | Next column | No | List field |
| 14 | Status | table column | Status | Last visible list column | No | List field |
| 15 | Create WO | section/form | Create WO [SEO, IC] | Below list | Yes | Create form |
| 16 | WorkOrder [id] | input | WorkOrder [id] | Form | Yes/partially system-derived | `id` notation is explicit |
| 17 | Description* | input | Description* | Form | Yes | Required marker shown |
| 18 | Status* | input/dropdown | Status* | Form | Yes | Required marker shown |
| 19 | Asset* | input/selection | Asset* | Form | Yes | Required marker shown |
| 20 | Asset Desc | text/input | Asset Desc | Form | Not specified | Likely related to Asset; exact behavior not stated |
| 21 | Serial # | text/input | Serial # | Form | Not specified | Exact behavior not stated |
| 22 | CM Item | text/input | CM Item | Form | Not specified | Exact behavior not stated |
| 23 | WorkType* | input/dropdown | WorkType* | Form | Yes | Required marker shown |
| 24 | PM | text/input | PM | Form | Not specified | Exact behavior not stated |
| 25 | PM desc | text/input | PM desc | Form | Not specified | Exact behavior not stated |
| 26 | Status Date | date/input | Status Date | Form | Not specified | Exact control not drawn |
| 27 | Created By | text | Created By | Form | Not specified | System/user information |
| 28 | Closed By | text | Closed By | Form | Not specified | System/user information |
| 29 | Autofill / fetched from DB | annotation | Autofill / fetched from DB | Below fields | No | Technical behavior note |
| 30 | Cancel | action | Cancel | Bottom of form | No | Explicit action |
| 31 | Save | action | Save | Bottom of form | No | Explicit action |
| 32 | Status editable | annotation | Status is Editable | Opened WO state | Yes | Explicitly stated |

## 5. Exact Field Details

### WorkOrder [id]

- Label: WorkOrder [id]
- Type: Input/text
- Position: Create WO form
- Required: Unknown
- Editable: Not clearly specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None shown
- Validation: Not specified
- Related controls: Description, Status, Asset
- Notes: Preserve the `[id]` notation as written.

### Description*

- Label: Description*
- Type: Input
- Position: Create WO form
- Required: Yes, based on `*`
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: None
- Validation: Not specified
- Related controls: WorkOrder
- Notes: Star is preserved as a required marker because it is explicitly drawn.

### Status*

- Label: Status*
- Type: Input/dropdown
- Position: Create WO form
- Required: Yes, based on `*`
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Status Date
- Notes: In the opened WO state, Status is explicitly editable.

### Asset*

- Label: Asset*
- Type: Input/selection
- Position: Create WO form
- Required: Yes, based on `*`
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Asset Desc, Serial #, CM Item
- Notes: The notebook suggests related asset details.

### WorkType*

- Label: WorkType*
- Type: Input/dropdown
- Position: Create WO form
- Required: Yes, based on `*`
- Editable: Yes
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: PM
- Notes: Preserve exact casing.

### PM

- Label: PM
- Type: Input/selection
- Position: Create WO form
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: PM desc
- Notes: No exact control is drawn.

### PM desc

- Label: PM desc
- Type: Text/input
- Position: Create WO form
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None shown
- Validation: Not specified
- Related controls: PM
- Notes: Preserve abbreviation.

### Status Date

- Label: Status Date
- Type: Date/text
- Position: Create WO form
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None
- Validation: Not specified
- Related controls: Status

### Created By / Closed By

- Labels: Created By; Closed By
- Type: Text
- Position: Lower portion of create/open form
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None
- Validation: Not specified
- Notes: Do not assume editability.

## 6. Tables / Lists

### Work Order List

Visible columns are represented in two handwritten rows. Preserve the sequence:

1. WorkOrder [1]
2. Description
3. WorkType
4. PM
5. PM desc
6. Asset
7. Status Date
8. Status

The notebook says the list is "on click openable WO", so a row/work order can be opened.

Search / Filter and Sort appear above the table.

## 7. Navigation

Source: User View  
Target: Work Order Tracking (CM)  
Trigger: Selecting Work Order Tracking (CM)  
Relationship: Module navigation [INFERRED]  
Confidence: Medium.

Source: Work Order Tracking (CM)  
Target: Opened WO  
Trigger: Selecting/clicking a WO row  
Relationship: Explicitly described as "on click openable WO"  
Confidence: High.

Source: Work Order Tracking (CM)  
Target: Create WO  
Trigger: Create New  
Relationship: Explicit  
Confidence: High.

## 8. User Interactions

- Search/filter work orders.
- Sort work orders.
- Open a work order by clicking it.
- Create a new work order.
- Save a work order.
- Cancel creation.
- Edit Status in an opened work order.
- Use role-based Create New behavior for SEO and IC as annotated.
- Autofill/fetch some information from DB as annotated.

## 9. Visual/Layout Instructions

- Keep list controls above the table.
- Search/Filter and Sort stay grouped together.
- Create New is positioned to the right side of this area.
- Preserve the role-based note around Create New.
- Keep the work-order table below these controls.
- Create/open form follows the list in the notebook.
- Preserve the compact multi-column arrangement implied by the handwritten field placement.
- Keep Cancel and Save together at the bottom, with Cancel to the left of Save.
- Do not add additional buttons.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Display work orders in a list/table.
- Provide Search / Filter.
- Provide Sort.
- Allow a WO to be opened by clicking it.
- Provide Create New.
- Create WO is annotated as role-based for SEO and IC.
- Create form must contain the listed fields.
- Required markers must be retained for Description, Status, Asset, and WorkType.
- Autofill/fetch-from-DB behavior must be retained where indicated.
- Save and Cancel must be present.
- Opened WO uses the same fields and allows Status editing.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Page name and list controls.
- Table field names.
- Create New.
- Role-based note.
- Create WO fields.
- Save/Cancel.
- Click-openable WO.
- Status editable in opened WO.
- Autofill/fetched from DB annotation.

### Inferred / Unclear

- Exact UI control types for most fields are not drawn.
- Exact role authorization mechanism is not specified.
- `[1]` after WorkOrder may be an example/index/count marker.
- Exact meaning of some list/table row wrapping is uncertain.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image 1: `C6E7CA6F-1203-420B-856C-0BC2499A348B.jpeg`
- Image 2: `6784C81B-0FE3-40A2-A0D9-304F5ABCFA81.jpeg`

### Confidence

Overall extraction confidence:
- High

### Potential OCR/Handwriting Issues

- Exact table row/column wrapping is somewhat ambiguous.
- `[1]` beside WorkOrder is preserved rather than interpreted as a functional value.
