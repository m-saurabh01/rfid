# Task Level Compliance

## 1. Page Purpose

The notebook describes a **Task Level Compliance** page associated with a work order/asset context. It contains shared asset-identification fields followed by a TLC list where compliance records can be updated or deleted.

## 2. Overall Layout

- The page appears after/within the Work Order Tracking flow.
- The notebook says the same fields are used "till Asset description".
- Below those shared fields is a **TLC list**.
- The TLC list is tabular.
- Action controls appear for each compliance record: Update, Compliance, Delete.

## 3. Page Hierarchy

```text
Task Level Compliance
├── Shared Work Order/Asset Fields
│   └── Fields through Asset Description
└── TLC List
    ├── Technician Name
    ├── Task Description
    ├── Long Desc
    ├── Compliance Date
    └── Action
        ├── Update
        ├── Compliance
        └── Delete
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Task Level Compliance | heading/section | Task Level Compliance | Main content | No | Page/function title |
| 2 | Shared fields through Asset description | form group | Same fields till Asset description | Above TLC list | Yes/varies | Reuses fields from WO flow |
| 3 | TLC list | table/list | TLC List | Below shared fields | Yes | Main record list |
| 4 | Technician Name | table column | Technician Name | First column | Not specified | |
| 5 | Task Description | table column | Task Description | Second column | Not specified | |
| 6 | Long Desc | table column | Long Desc | Third column | Not specified | Preserve abbreviation |
| 7 | Compliance date | table column | Compliance date | Fourth column | Not specified | Date field |
| 8 | Action | table column | Action | Final column | Yes | Contains actions |
| 9 | Update | action | Update | Action column | Yes | Explicit |
| 10 | Compliance | action | Compliance | Action column | Yes | Explicit |
| 11 | Delete | action | Delete | Action column | Yes | Explicit |

## 5. Exact Field Details

### Shared fields through Asset description

- Label: Same fields till Asset description
- Type: Reused work-order/asset form fields
- Position: Above TLC list
- Required: Not re-specified in this sketch
- Editable: Varies according to the original field definition
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: TLC list
- Notes: Do not duplicate or invent fields beyond those already established in the Work Order Tracking flow; the explicit boundary is "till Asset description".

## 6. Tables / Lists

### TLC List

Column order:

| Column Order | Column |
|-------------:|--------|
| 1 | Technician Name |
| 2 | Task Description |
| 3 | Long Desc |
| 4 | Compliance date |
| 5 | Action |

Action column contains:

- Update
- Compliance
- Delete

No sorting, pagination, filtering, or search is shown for TLC.

## 7. Navigation

Source: Work Order Tracking (CM)  
Target: Task Level Compliance  
Trigger: The notebook places Task Level Compliance after the opened-WO flow; exact trigger is not drawn.  
Relationship: Related work-order function  
Confidence: [INFERRED].

## 8. User Interactions

- View TLC records.
- Update a record.
- Perform Compliance action.
- Delete a record.

No other interaction is explicitly shown.

## 9. Visual/Layout Instructions

- Keep shared fields above the TLC list.
- The TLC list should be visually separated from the shared fields.
- Preserve the five-column table structure.
- Keep Action as the final column.
- Keep Update, Compliance, and Delete grouped under Action.
- Do not add search, filters, charts, status cards, or other controls.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Reuse the common fields through Asset description.
- Display a TLC List.
- Columns must be Technician Name, Task Description, Long Desc, Compliance date, and Action.
- Provide Update, Compliance, and Delete actions.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Page/function name.
- Shared-field boundary.
- TLC list.
- All five table headings.
- All three actions.

### Inferred / Unclear

- Exact trigger from the opened WO to TLC is not shown.
- Exact input/control types for shared fields are inherited from the Work Order Tracking specification rather than this sketch.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `6784C81B-0FE3-40A2-A0D9-304F5ABCFA81.jpeg`

### Confidence

Overall extraction confidence:
- High

### Potential OCR/Handwriting Issues

- None significant in the TLC column names.
