# Arming / De-arming

## 1. Page Purpose

The notebook describes an **Arming/De-arming** page for recording armament-related information against an asset. It contains shared asset fields followed by a list of arming/de-arming records and actions. A separate note states that the same structure applies to De-arming, with an **Unload** button.

## 2. Overall Layout

Top-to-bottom:

1. Arming / De-arming heading.
2. Shared fields through Asset Description.
3. List of Arming/De-arming.
4. A tabular/list structure containing armament, station, quantity, status, and personnel information.
5. Action controls at the bottom: Save, Load, Delete.
6. A separate note says De-arming uses the same structure with an Unload button.

## 3. Page Hierarchy

```text
Arming / De-arming
├── Shared Fields
│   └── Same fields till Asset Description
├── List of Arming / De-arming
│   └── Record fields
│       ├── Hand point
│       ├── Build item
│       ├── Station No.
│       ├── Armament position
│       ├── Armament Item/Gun No
│       ├── Description
│       ├── Part
│       ├── Serial #
│       ├── Lot No.
│       ├── Current Quantity
│       ├── Load Quantity
│       ├── Total Quantity
│       ├── Remarks
│       ├── Status
│       └── Loaded/Unloaded By
└── Actions
    ├── Save
    ├── Load
    └── Delete

De-arming
└── Same structure
    └── Unload button instead of/alongside Load
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Arming / De-arming | heading | Arming / De-arming | Top | No | Page title |
| 2 | Shared fields | form group | Same field till Asset description | Below heading | Varies | Reused common fields |
| 3 | Arming/De-arming list | table/list | List of Arming/De-arming | Below shared fields | Yes | Main content |
| 4 | Hand point | field/column | Hand point | First field group | Not specified | Exact meaning preserved |
| 5 | Build item | field/column | Build item | Next | Not specified | |
| 6 | Station No. | field/column | Station No. | Next | Not specified | |
| 7 | Armament position | field/column | Armament position | Next | Not specified | |
| 8 | Armament Item/Gun No | field/column | Armament Item/Gun No | Next | Not specified | Preserve slash |
| 9 | Description | field/column | Description | Next | Not specified | |
| 10 | Part | field/column | part | Next | Not specified | Preserve wording/case as written |
| 11 | Serial # | field/column | Serial # | Next | Not specified | |
| 12 | Lot No. | field/column | Lot No. | Next | Not specified | |
| 13 | Current Quantity | field/column | Current Quantity | Next | Not specified | |
| 14 | Load Quantity | field/column | Load Quantity | Next | Not specified | |
| 15 | Total Quantity | field/column | Total Quantity | Next | Not specified | |
| 16 | Remarks | field/column | Remarks | Next | Not specified | |
| 17 | Status | field/column | Status | Next | Not specified | |
| 18 | Loaded/Unloaded By | field/column | Loaded/Unloaded By | Final data field | Not specified | |
| 19 | Save | action | Save | Bottom action row | No | Explicit |
| 20 | Load | action | Load | Bottom action row | No | Explicit for arming |
| 21 | Delete | action | Delete | Bottom action row | No | Explicit |
| 22 | Unload | action | Unload | De-arming state | No | Explicit note |

## 5. Exact Field Details

### Armament Item/Gun No

- Label: Armament Item/Gun No
- Type: Input/selection field
- Position: Within arming record
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Description, Part, Serial #
- Notes: Preserve slash and exact terminology.

### Current Quantity

- Label: Current Quantity
- Type: Numeric/text field
- Position: Quantity group
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None shown
- Validation: Not specified
- Related controls: Load Quantity, Total Quantity
- Notes: Do not invent calculation rules.

### Load Quantity

- Label: Load Quantity
- Type: Numeric/text field
- Position: Quantity group
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: None shown
- Validation: Not specified
- Related controls: Current Quantity, Total Quantity

### Status

- Label: Status
- Type: Field
- Position: Near end of record
- Required: Unknown
- Editable: Not specified
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Loaded/Unloaded By

## 6. Tables / Lists

The notebook does not provide a clean bordered table, but it lays out the fields as a record/list structure. Preserve the written field sequence rather than converting it into a different information architecture.

## 7. Navigation

Source: User View / Work Order-related flow  
Target: Arming / De-arming  
Trigger: Not explicitly drawn  
Relationship: Module/function navigation [INFERRED]  
Confidence: Low-Medium.

Within the page:

Source: Arming state  
Target: De-arming state  
Trigger: De-arming operation  
Relationship: Same structure, with Unload button  
Confidence: High.

## 8. User Interactions

- Enter/view armament details.
- Save.
- Load.
- Delete.
- For De-arming, use Unload.

No other interactions are specified.

## 9. Visual/Layout Instructions

- Preserve the long horizontal/record-like arrangement shown in the sketch.
- Keep shared asset fields above the arming/de-arming list.
- Keep the action row at the bottom.
- Do not transform the page into cards or a wizard.
- De-arming must retain the same field structure.
- Include the explicit Unload action for De-arming.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Reuse fields through Asset Description.
- Provide an Arming/De-arming list.
- Include all armament and quantity fields shown.
- Provide Save, Load, Delete.
- Provide Unload for De-arming.
- Preserve Loaded/Unloaded By.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Page title.
- Shared fields.
- All listed armament fields.
- Save, Load, Delete.
- Same structure for De-arming with Unload.

### Inferred / Unclear

- `Hand point` meaning is not explained.
- Exact control types are not drawn.
- Whether Load and Save apply to one row or the whole record is not explicitly specified.
- Quantity calculation/validation is not specified.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `D0FAA03C-1A4C-4F6F-AB90-2C1515D4D7E6.jpeg`

### Confidence

Overall extraction confidence:
- Medium-High

### Potential OCR/Handwriting Issues

- `Hand point` may have a domain-specific meaning that is not explained.
