# User View

## 1. Page Purpose

The notebook describes a post-login **User View** containing a common application header, a list of available application modules, a welcome message, and an A/C Details section.

## 2. Overall Layout

From top to bottom:

1. Page heading: User View.
2. Header row:
   - A/C
   - Name
   - Version
3. A welcome row:
   - Welcome `<Name>`
   - Logout on the right.
4. Main application/module list:
   - Planned Asset
   - Work Order Tracking (CM)
   - FLB
   - DUEGIN [UNCLEAR - HANDWRITING]
   - FSC
   - Snag Reporting
   - Consolidated Report
5. A bracketed **Welcome Message** area is shown below the module list.
6. **A/C Details** appears below that as a tabular information section.

## 3. Page Hierarchy

```text
User View
├── Header
│   ├── A/C
│   ├── Name
│   └── Version
├── User Row
│   ├── Welcome <Name>
│   └── Logout
├── Application/Module List
│   ├── Planned Asset
│   ├── Work Order Tracking (CM)
│   ├── FLB
│   ├── DUEGIN [UNCLEAR - HANDWRITING]
│   ├── FSC
│   ├── Snag Reporting
│   └── Consolidated Report
├── Welcome Message
└── A/C Details
    └── Details table
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | User View | heading | User View | Top of main page | No | Page title |
| 2 | A/C | header text | A/C | Header left | No | Exact meaning not specified |
| 3 | Name | header text | Name | Header near A/C | No | User/application context |
| 4 | Version | header text | Version | Header right | No | Version information |
| 5 | Welcome message | text | Welcome `<Name>` | Below header, left | No | Dynamic name placeholder is written |
| 6 | Logout | navigation/action | logout | Below header, right | No | Explicit action |
| 7 | Planned Asset | navigation item | Planned Asset | First module item | No | Module link/navigation |
| 8 | Work Order Tracking (CM) | navigation item | Work Order Tracking (CM) | Second module item | No | Module link/navigation |
| 9 | FLB | navigation item | FLB | Third module item | No | Module link/navigation |
| 10 | DUEGIN | navigation item | DUEGIN [UNCLEAR - HANDWRITING] | Fourth module item | No | Handwriting ambiguous |
| 11 | FSC | navigation item | FSC | Fifth module item | No | Module link/navigation |
| 12 | Snag Reporting | navigation item | Snag Reporting | Sixth module item | No | Module link/navigation |
| 13 | Consolidated Report | navigation item | Consolidated Report | Seventh module item | No | Module link/navigation |
| 14 | Welcome Message | section/text | Welcome Message | Below module list | No | Bracketed placeholder/section |
| 15 | A/C Details | section/heading | A/C Details | Below Welcome Message | No | Contains details table |

## 5. Exact Field Details

### Welcome `<Name>`

- Label: Welcome `<Name>`
- Type: Text
- Position: Below the header row, left side
- Required: Unknown
- Editable: No
- Default value: User's name is implied by the placeholder
- Placeholder: `<Name>`
- Options: None
- Validation: Not applicable
- Related controls: Logout
- Notes: Preserve the angle-bracket placeholder concept.

### Logout

- Label: logout
- Type: Action/link
- Position: Right side of the welcome row
- Required: No
- Editable: No
- Default value: Not applicable
- Placeholder: Not applicable
- Options: None
- Validation: Not specified
- Related controls: Welcome `<Name>`

## 6. Tables / Lists

### Application/Module List

The notebook shows a vertical list of seven application/module entries. Preserve this order exactly:

| Order | Module |
|------:|--------|
| 1 | Planned Asset |
| 2 | Work Order Tracking (CM) |
| 3 | FLB |
| 4 | DUEGIN [UNCLEAR - HANDWRITING] |
| 5 | FSC |
| 6 | Snag Reporting |
| 7 | Consolidated Report |

Each is represented as an arrow/bullet-style navigation item in the sketch.

### A/C Details

The sketch places an A/C Details table below the Welcome Message.

Visible/likely headings and fields include:

| Column/Field | Reading | Confidence |
|---|---|---|
| LCN No. | LCN No. | High |
| A/C No. | A/C No. | High |
| Model | Model | High |
| Variation | Variation | High |
| Exported Date | Exported Date | High |
| Imported Date | Imported Date | High |
| Base loc | Base loc | High |
| Delt loc | Delt loc | High |
| Delt loc Base | Delt loc Base [INFERRED] | Medium |
| Status | Status | High |

The exact column arrangement in the lower table is not fully clear from handwriting, so the implementation agent must preserve the visible ordering without inventing additional columns.

## 7. Navigation

Source: User View  
Target: Planned Asset  
Trigger: Selecting the Planned Asset item  
Relationship: Module navigation [INFERRED from list presentation]  
Confidence: Medium.

Source: User View  
Target: Work Order Tracking (CM)  
Trigger: Selecting the module item  
Relationship: Module navigation [INFERRED]  
Confidence: Medium.

Source: User View  
Target: FLB  
Trigger: Selecting the module item  
Relationship: Module navigation [INFERRED]  
Confidence: Medium.

The same pattern applies to DUEGIN, FSC, Snag Reporting, and Consolidated Report, but the exact click behavior is not explicitly written.

## 8. User Interactions

- Navigate to listed modules.
- Logout.
- View A/C Details.
- View the welcome message.

Do not invent edit functionality for A/C Details.

## 9. Visual/Layout Instructions

- Keep the page as a vertically organized application landing/user view.
- Header content is horizontal.
- Welcome `<Name>` and logout form a separate row below the header.
- Module entries are stacked vertically with arrow markers.
- Welcome Message appears below the module list.
- A/C Details is below Welcome Message.
- Preserve the large vertical separation between the module list and the lower details section shown in the sketch.
- Do not introduce a sidebar, dashboard cards, charts, or summary metrics.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Show A/C, Name, and Version in the header.
- Show Welcome `<Name>` and logout below the header.
- Display all seven module/navigation entries in the exact order shown.
- Display a Welcome Message section.
- Display A/C Details below the Welcome Message.
- Preserve the fields shown for A/C Details.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- User View title.
- Header labels and ordering.
- Welcome `<Name>`.
- Logout.
- Module list and order.
- Welcome Message section.
- A/C Details section.

### Inferred / Unclear

- `DUEGIN` is uncertain handwriting.
- Exact table column grouping for A/C Details is unclear.
- The exact meaning of `Delt loc Base` is uncertain.
- Module click behavior is inferred from the arrow/list presentation.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `D0D03E3D-40E5-4538-B2E6-3DA5A314E99B.jpeg`

### Confidence

Overall extraction confidence:
- Medium-High

### Potential OCR/Handwriting Issues

- `DUEGIN` may be another application/module name.
- Lower A/C Details table column grouping is partially ambiguous.
