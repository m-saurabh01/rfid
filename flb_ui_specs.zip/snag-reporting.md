# SNAG Reporting

## 1. Page Purpose

This screen represents **SNAG REPORTING**. It provides:

- a search control,
- a `Create Snag` action,
- a list of created snags,
- and a `Create Snag Form` containing the fields shown in the notebook.

## 2. Overall Layout

Top-to-bottom layout:

1. Page heading: **SNAG REPORTING**.
2. A `Search bar` appears toward the upper-left.
3. A `Create Snag` action appears toward the upper-right on the same general row.
4. A list/table of created snags follows, with the listed fields.
5. A `Create Snag Form` appears below the created-snags list.
6. The form contains multiple rows of fields.
7. `[Cancel]` and `[Save]` appear at the bottom of the form, horizontally grouped.

## 3. Page Hierarchy

```text
Page
├── Heading: SNAG REPORTING
├── Search bar
├── Create Snag
├── List of Snag Created
│   ├── Snag
│   ├── Description
│   ├── Asset
│   ├── Snag Category
│   ├── Snag Status
│   ├── Reported By
│   └── Reported Date (time)
└── Create Snag Form
    ├── Snag No.
    ├── Description
    ├── Asset
    ├── Snag status
    ├── Reported By
    ├── Reported Date
    ├── Snag Category
    ├── Failure Class
    ├── Problem Code
    ├── Cause
    ├── Remedy
    ├── WDC
    ├── ATA/SN/S code
    ├── Status Date
    ├── Corrective Action
    ├── Summary
    ├── Cancel
    └── Save
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Page heading | heading | SNAG REPORTING | Top | No | |
| 2 | Search bar | search | Search bar | Upper-left | Yes | |
| 3 | Create Snag | button/action | Create Snag | Upper-right | No | |
| 4 | Snag | field/column | Snag | List, row 1 | Unknown | |
| 5 | Description | field/column | Description | List, row 1 | Unknown | |
| 6 | Asset | field/column | Asset | List, row 1 | Unknown | |
| 7 | Snag Category | field/column | Snag Category | List, row 1 | Unknown | |
| 8 | Snag Status | field/column | Snag Status | List, row 2 | Unknown | |
| 9 | Reported By | field/column | Reported By | List, row 2 | Unknown | |
| 10 | Reported Date (time) | field/column | Reported Date (time) | List, row 2 | Unknown | |
| 11 | List of Snag Created | list/table | List of Snag Created | Below list headings | No | Explicit annotation |
| 12 | Create Snag Form | heading/section | Create Snag Form | Below list | No | |
| 13 | Snag No. | field | Snag No. | Form, first row, left | Unknown | |
| 14 | Description | field | Description | Form, first row | Unknown | |
| 15 | Asset | field | Asset | Form, first row | Unknown | |
| 16 | Snag status | field | Snag status | Form, first row, right | Unknown | |
| 17 | Reported By | field | Reported By | Form, second row | Unknown | |
| 18 | Reported Date | field | Reported Date | Form, second row | Unknown | |
| 19 | Snag Category | field | Snag Category | Form, second row, right | Unknown | |
| 20 | Failure Class | field | Failure Class | Form, third row | Unknown | |
| 21 | Problem Code | field | Problem Code | Form, third row | Unknown | |
| 22 | Cause | field | Cause | Form, third row, right | Unknown | |
| 23 | Remedy | field | Remedy | Form, fourth row, left | Unknown | |
| 24 | WDC | field | WDC | Form, fourth row | Unknown | |
| 25 | ATA/SN/S code | field | ATA/SN/S code | Form, fourth row, right | Unknown | Preserve abbreviation |
| 26 | Status Date | field | Status Date | Form, fifth row, left | Unknown | |
| 27 | Corrective Action | field | Corrective Action | Form, fifth row, center | Unknown | |
| 28 | Summary | field | Summary | Form, fifth row, right | Unknown | |
| 29 | Cancel | button/action | Cancel | Bottom of form | No | |
| 30 | Save | button/action | Save | Bottom of form | No | |

## 5. Exact Field Details

### Search bar

- Label: Search bar
- Type: Search input
- Position: Upper-left, above the snag list
- Required: No
- Editable: Yes
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Snag list
- Notes: Search is explicitly bracketed as a control.

### Create Snag

- Label: Create Snag
- Type: Button/action
- Position: Upper-right of the search row
- Required: No
- Editable: No
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Create Snag Form
- Notes: Explicit action.

### Snag No.

- Label: Snag No.
- Type: Form field
- Position: First row, left
- Required: Unknown
- Editable: Unknown
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Create Snag form
- Notes: Exact input type is not specified.

### Reported Date

- Label: Reported Date
- Type: Form field
- Position: Second row
- Required: Unknown
- Editable: Unknown
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Reported By
- Notes: The list uses `Reported Date (time)` while the form uses `Reported Date`; preserve both labels.

### Corrective Action

- Label: Corrective Action
- Type: Form field
- Position: Fifth row, center
- Required: Unknown
- Editable: Unknown
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Status Date, Summary
- Notes: Preserve the field label exactly.

### Cancel

- Label: Cancel
- Type: Button/action
- Position: Bottom of form
- Required: No
- Editable: No
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: None
- Validation: Not specified in sketch
- Related controls: Save
- Notes: Explicitly shown in brackets.

### Save

- Label: Save
- Type: Button/action
- Position: Bottom of form, right of Cancel
- Required: No
- Editable: No
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: None
- Validation: Not specified in sketch
- Related controls: Cancel
- Notes: Explicitly shown in brackets.

## 6. Tables / Lists

### List of Snag Created

The notebook identifies the list with these visible fields:

| Column/Field Order | Column |
|-------------------:|--------|
| 1 | Snag |
| 2 | Description |
| 3 | Asset |
| 4 | Snag Category |
| 5 | Snag Status |
| 6 | Reported By |
| 7 | Reported Date (time) |

No sorting, pagination, selection, or row actions are specified.

## 7. Navigation

Source: SNAG REPORTING
Target: Create Snag Form
Trigger: `Create Snag`
Relationship: Opens/displays the create form
Confidence: High

## 8. User Interactions

- Search the snag list.
- Create a snag.
- Enter/update fields in the Create Snag Form where applicable.
- Cancel the form.
- Save the form.

Do not add edit/delete/close/filter actions unless separately specified.

## 9. Visual/Layout Instructions

- Keep the page title at the top.
- Put Search bar on the left and Create Snag on the right of the same upper area.
- Keep the snag list above the create form.
- Preserve the seven list fields and their relative ordering.
- Keep the Create Snag Form as a separate section.
- Preserve the five-row grouping of form fields.
- Keep Cancel and Save together at the bottom.
- Do not invent colors, icons, cards, dialogs, or other components.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Provide a SNAG REPORTING page.
- Provide a Search bar.
- Provide a Create Snag action.
- Show a list of created snags with the seven specified fields.
- Provide a Create Snag Form with the specified fields.
- Provide Cancel and Save actions at the bottom of the form.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Search bar and Create Snag are shown.
- List of Snag Created is shown.
- All listed form labels are visible.
- Cancel and Save are visible.

### Inferred / Unclear

- Whether `Snag` in the list is a number, identifier, or another representation is not specified.
- Exact control types are not specified.
- Required/optional rules are not specified.
- No field validation is specified.
- Exact behavior of Search is not described.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `IMG_FA344FAA-58CB-41B1-BC0B-C686090992EB.jpeg`

### Confidence

Overall extraction confidence:
- High

### Potential OCR/Handwriting Issues

- `ATA/SN/S code` is handwritten and should not be expanded or corrected without additional evidence.
- `Reported Date (time)` is preserved as written in the list.
