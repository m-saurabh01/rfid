# Unified Asset Log Book Sec 12

## 1. Page Purpose

This reference represents a **UNIFIED Asset log book Sec 12** page focused on a **Due List** and the maintenance items associated with an asset.

## 2. Overall Layout

- Page heading centered near the top: **UNIFIED Asset log book Sec 12**.
- Immediately below is **Due List**.
- The Due List has two rows of fields:
  - Asset No.
  - Remaining Hours
  - Remaining days
  - Remaining Value
  - Report Type
  - Job plan
- Below the Due List is a compact asset-identification/detail area containing:
  - Top Asset No.
  - Description
  - Model
  - SERIAL NO.
  - CM Item No.
  - Current Meter
  - value : AF-HC [handwriting unclear]
- A `LOGS` heading follows.
- A `Legend` heading follows.
- The legend contains an example such as:
  - `>? : Maintenance activity within`
  - `5hr 5day, 5 occurrences`
  The exact first token is unclear.
- A large lower table/list contains maintenance/work-planning fields:
  - Asset
  - Serial No.
  - Part No./Part Desc.
  - CIG No.
  - Build Item
  - PM No.
  - PM Description
  - Work Type
  - Job plan
  - Description
  - Freq Parameter
  - Frequency
  - Current Value
  - Due
  - Remaining

## 3. Page Hierarchy

```text
Page
├── UNIFIED Asset log book Sec 12
├── Due List
│   ├── Asset No.
│   ├── Remaining Hours
│   ├── Remaining days
│   ├── Remaining Value
│   ├── Report Type
│   └── Job plan
├── Asset details
│   ├── Top Asset No.
│   ├── Description
│   ├── Model
│   ├── SERIAL NO.
│   ├── CM Item No.
│   └── Current Meter value
├── LOGS
├── Legend
│   └── Maintenance activity threshold example
└── Maintenance/work list
    ├── Asset
    ├── Serial No.
    ├── Part No./Part Desc.
    ├── CIG No.
    ├── Build Item
    ├── PM No.
    ├── PM Description
    ├── Work Type
    ├── Job plan
    ├── Description
    ├── Freq Parameter
    ├── Frequency
    ├── Current Value
    ├── Due
    └── Remaining
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Page heading | heading | UNIFIED Asset log book Sec 12 | Top/center | No | |
| 2 | Due List | heading/section | Due List | Below title | No | |
| 3 | Asset No. | field/column | Asset No. | Due List, row 1 left | Unknown | |
| 4 | Remaining Hours | field/column | Remaining Hours | Due List, row 1 center | Unknown | |
| 5 | Remaining days | field/column | Remaining days | Due List, row 1 right | Unknown | |
| 6 | Remaining Value | field/column | Remaining Value | Due List, row 2 left | Unknown | |
| 7 | Report Type | field/column | Report Type | Due List, row 2 center | Unknown | |
| 8 | Job plan | field/column | Job plan | Due List, row 2 right | Unknown | |
| 9 | Top Asset No. | field/column | Top Asset No. | Asset details, row 1 left | Unknown | |
| 10 | Description | field/column | Description | Asset details, row 1 center | Unknown | |
| 11 | Model | field/column | Model | Asset details, row 1 right | Unknown | |
| 12 | SERIAL NO. | field/column | SERIAL NO. | Asset details, row 2 left | Unknown | |
| 13 | CM Item No. | field/column | CM Item No. | Asset details, row 2 center | Unknown | |
| 14 | Current Meter value | field/column | Current Meter value : AF-HC | Asset details, row 2 right | Unknown | |
| 15 | LOGS | heading | LOGS | Below asset details | No | |
| 16 | Legend | heading | Legend | Below LOGS | No | |
| 17 | Maintenance threshold legend | annotation | [unclear] : Maintenance activity within 5hr 5day, 5 occurrences | Below Legend | No | First token is unclear |
| 18 | Asset | field/column | Asset | Lower list | Unknown | |
| 19 | Serial No. | field/column | Serial No. | Lower list | Unknown | |
| 20 | Part No./Part Desc. | field/column | Part No./Part Desc. | Lower list | Unknown | |
| 21 | CIG No. | field/column | CIG No. | Lower list | Unknown | |
| 22 | Build Item | field/column | Build Item | Lower list | Unknown | |
| 23 | PM No. | field/column | PM No. | Lower list | Unknown | |
| 24 | PM Description | field/column | PM Description | Lower list | Unknown | |
| 25 | Work Type | field/column | Work Type | Lower list | Unknown | |
| 26 | Job plan | field/column | Job plan | Lower list | Unknown | |
| 27 | Description | field/column | Description | Lower list | Unknown | |
| 28 | Freq Parameter | field/column | Freq Parameter | Lower list | Unknown | |
| 29 | Frequency | field/column | Frequency | Lower list | Unknown | |
| 30 | Current Value | field/column | Current Value | Lower list | Unknown | |
| 31 | Due | field/column | Due | Lower list | Unknown | |
| 32 | Remaining | field/column | Remaining | Lower list | Unknown | |

## 5. Exact Field Details

### Due List

- Label: Due List
- Type: List/table
- Position: Immediately below page title
- Required: No
- Editable: No/Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Asset detail area
- Notes: Contains six named fields.

### Current Meter value

- Label: Current Meter value : AF-HC
- Type: Field/label
- Position: Right side of asset detail area
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Meter-related lower list
- Notes: `AF-HC` is preserved exactly because its meaning is not certain.

### Maintenance threshold legend

- Label/Text: [UNCLEAR] : Maintenance activity within 5hr 5day, 5 occurrences
- Type: Legend/annotation
- Position: Under Legend
- Required: No
- Editable: No
- Default value: Not applicable
- Placeholder: Not applicable
- Options: Not applicable
- Validation: Not applicable
- Related controls: Lower maintenance list
- Notes: The symbol/token before the colon is unclear in the handwriting.

## 6. Tables / Lists

### Due List

| Column Order | Column |
|-------------:|--------|
| 1 | Asset No. |
| 2 | Remaining Hours |
| 3 | Remaining days |
| 4 | Remaining Value |
| 5 | Report Type |
| 6 | Job plan |

### Asset detail block

| Position Order | Field |
|---|---|
| 1 | Top Asset No. |
| 2 | Description |
| 3 | Model |
| 4 | SERIAL NO. |
| 5 | CM Item No. |
| 6 | Current Meter value : AF-HC |

### Maintenance/work list

| Column Order | Column |
|-------------:|--------|
| 1 | Asset |
| 2 | Serial No. |
| 3 | Part No./Part Desc. |
| 4 | CIG No. |
| 5 | Build Item |
| 6 | PM No. |
| 7 | PM Description |
| 8 | Work Type |
| 9 | Job plan |
| 10 | Description |
| 11 | Freq Parameter |
| 12 | Frequency |
| 13 | Current Value |
| 14 | Due |
| 15 | Remaining |

No sorting, filtering, pagination, selection, or row actions are specified.

## 7. Navigation

No explicit navigation arrow or destination is shown on this page.

## 8. User Interactions

No explicit user interactions are shown. The page is primarily represented as a report/list view.

## 9. Visual/Layout Instructions

- Keep the main title centered as drawn.
- Keep Due List immediately below it.
- Preserve the two-row Due List grouping.
- Keep asset detail fields below the Due List and above LOGS.
- Keep `LOGS` and `Legend` as separate headings.
- Keep the legend above the lower maintenance list.
- Preserve the large horizontal lower-list structure.
- Do not turn the report into cards or add controls not shown.
- Styling/colors are not specified.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Display the Unified Asset Log Book Sec 12 title.
- Display the Due List with the six named fields.
- Display the asset identification/detail fields.
- Display LOGS and Legend.
- Display the maintenance/work list with the fifteen named fields.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Title and section names are visible.
- Due List fields are visible.
- Asset details are visible.
- LOGS and Legend are visible.
- Lower maintenance/work list fields are visible.

### Inferred / Unclear

- The exact legend symbol/text before `Maintenance activity within` is unclear.
- `AF-HC` may be a domain-specific meter/value code; do not expand it.
- Exact UI control types and editability are not specified.
- The meaning of `CIG No.` is not specified.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `IMG_5EB11079-D1CB-4295-8F2A-90517156D652.jpeg`

### Confidence

Overall extraction confidence:
- Medium

### Potential OCR/Handwriting Issues

- The first character/token in the legend is unclear.
- `Current Meter value : AF-HC` is preserved without expansion.
