# FLB Reference UI Specifications

These Markdown files were reverse-engineered from the supplied notebook reference images. The notebook sketches are the primary source of truth.

## Files

- `flb-overview.md` — FLB Flight Log Book, Sortie Accept/Reject and Post Flight Data.
- `flb-meters-arming.md` — FLB Meters and Aiming/De-arming log.
- `snag-reporting.md` — SNAG REPORTING and Create Snag Form.
- `reports-fsc.md` — Reports / FSC and sections 1–10 plus Due List.
- `unified-asset-log-book.md` — Unified Asset Log Book Sec 12 / Due List / Logs.
- `consolidated-report.md` — Consolidated Report.
- `meter-compliance-install-arming.md` — Meter compliance, Asset Install/remove, ARMING / DE-ARMING.
- `flb-details.md` — FLB details sections n7–n10.

## Source Image Mapping

| Specification | Source image |
|---|---|
| flb-overview.md | IMG_36A718CB-759C-4BA2-A135-12CB000F17A7.jpeg |
| flb-meters-arming.md | IMG_804551F4-CFED-40AB-B770-21C35EA2941B.jpeg |
| snag-reporting.md | IMG_FA344FAA-58CB-41B1-BC0B-C686090992EB.jpeg |
| reports-fsc.md | IMG_D0F60A27-B41D-41D3-8948-F1DB899A5A95.jpeg; IMG_879E716B-74F8-4C20-B084-2B623395F66D.jpeg; IMG_652E9A0E-0FFA-4FE5-AC5A-1C9427269BF3.jpeg |
| unified-asset-log-book.md | IMG_5EB11079-D1CB-4295-8F2A-90517156D652.jpeg |
| consolidated-report.md | IMG_F7563BD4-FFF8-4CAB-A403-63EFE4DDE927.jpeg |
| meter-compliance-install-arming.md | IMG_743E4D47-4AD7-467D-A6C0-398B5D2E21C2.jpeg |
| flb-details.md | IMG_CB556C43-2E0A-4098-9318-179FFF1C2F31.jpeg |

The remaining supplied image is treated as the source for the consolidated Reports continuation where applicable.
