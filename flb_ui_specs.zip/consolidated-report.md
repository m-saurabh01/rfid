# Consolidated Report

## 1. Page Purpose

This reference defines a **CONSOLIDATED REPORT** containing several groups of maintenance and asset information.

The notebook shows three numbered areas:

1. **EMMSuite activity details**
2. **Planned Assets**
3. **WORK ORDER Details**

A nested/detail relationship is shown beneath Work Order Details for task compliance information.

## 2. Overall Layout

- Heading: **CONSOLIDATED REPORT**.
- Section `n1 → Emmsuite activity details` appears first.
- Section `n2 → Planned Assets` appears below.
- Section `n3 → WORK ORDER Details` appears below Planned Assets.
- Work Order Details contains multiple rows of fields.
- An arrow from the work-order area points to a lower task-compliance detail area.
- The lower area includes task compliance, task description, compliance date, technician name, and log description.

## 3. Page Hierarchy

```text
Page
├── CONOLIDATED REPORT
├── n1 → Emmsuite activity details
│   ├── Record No.
│   ├── Aircraft No.
│   ├── Data Imported Date
│   └── Closing Date
├── n2 → Planned Assets
│   ├── Asset
│   ├── Description
│   ├── Serial Num
│   └── CM Item
└── n3 → WORK ORDER Details
    ├── Work Order
    ├── Description
    ├── Status
    ├── Asset
    ├── Asset Description
    ├── Serial No.
    ├── CM Item
    ├── Work type
    ├── PM
    ├── PM Desc
    ├── Created By
    ├── Closure / Cancelled Date
    ├── Closed By
    └── Task detail
        ├── Task compliance
        ├── Task description
        ├── Compliance date
        ├── Technician
        ├── Technician name
        └── Log description
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Page heading | heading | CONSOLIDATED REPORT | Top | No | |
| 2 | Section 1 | section | n1 → Emmsuite activity details | Upper | No | |
| 3 | Record No. | field/column | Record No. | Section 1, first row, left | Unknown | |
| 4 | Aircraft No. | field/column | Aircraft No. | Section 1, first row, center | Unknown | |
| 5 | Data Imported Date | field/column | Data Imported Date | Section 1, first row, right | Unknown | |
| 6 | Closing Date | field/column | Closing Date | Section 1, second row, left | Unknown | |
| 7 | Section 2 | section | n2 → Planned Assets | Below section 1 | No | |
| 8 | Asset | field/column | Asset | Section 2, first row, left | Unknown | |
| 9 | Description | field/column | Description | Section 2, first row, center | Unknown | |
| 10 | Serial Num | field/column | Serial Num | Section 2, first row, right-center | Unknown | |
| 11 | CM Item | field/column | CM Item | Section 2, first row, right | Unknown | |
| 12 | Section 3 | section | n3 → WORK ORDER Details | Below section 2 | No | |
| 13 | Work Order | field/column | Work Order | Section 3, first row, left | Unknown | |
| 14 | Description | field/column | Description | Section 3, first row | Unknown | |
| 15 | Status | field/column | Status | Section 3, first row | Unknown | |
| 16 | Asset | field/column | Asset | Section 3, first row, right | Unknown | |
| 17 | Asset Description | field/column | Asset Description | Section 3, second row, left | Unknown | |
| 18 | Serial No. | field/column | Serial No. | Section 3, second row | Unknown | |
| 19 | CM Item | field/column | CM Item | Section 3, second row, right | Unknown | |
| 20 | Work type | field/column | Work type | Section 3, third row, left | Unknown | |
| 21 | PM | field/column | PM | Section 3, third row | Unknown | |
| 22 | PM Desc | field/column | PM Desc | Section 3, third row | Unknown | |
| 23 | Created By | field/column | Created By | Section 3, third row, right | Unknown | |
| 24 | Closure / Cancelled Date | field/column | Closure / cancelled Date | Section 3, fourth row, left | Unknown | |
| 25 | Closed By | field/column | Closed By | Section 3, fourth row, right | Unknown | |
| 26 | Task compliance | field/column | Task compliance | Lower detail | Unknown | Connected by arrow |
| 27 | Task description | field/column | Task description | Lower detail | Unknown | |
| 28 | Compliance date | field/column | Compliance date | Lower detail | Unknown | |
| 29 | Technician | field/column | Technician | Lower detail | Unknown | |
| 30 | Technician name | field/column | Technician name | Lower detail | Unknown | |
| 31 | Log description | field/column | log description | Lower detail | Unknown | |

## 5. Exact Field Details

### Record No.

- Label: Record No.
- Type: Field/column
- Position: Section 1, first row, left
- Required: Unknown
- Editable: Unknown
- Default value: Not specified in sketch
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Section 1
- Notes: Part of Emmsuite activity details.

### Aircraft No.

- Label: Aircraft No.
- Type: Field/column
- Position: Section 1, first row, center
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Section 1
- Notes: Preserve wording.

### Planned Assets

- Label: Planned Assets
- Type: Section
- Position: Below Emmsuite activity details
- Required: No
- Editable: No
- Default value: Not applicable
- Placeholder: Not applicable
- Options: Not applicable
- Validation: Not applicable
- Related controls: Work Order Details
- Notes: Section 2.

### Work Order Details

- Label: WORK ORDER Details
- Type: Section
- Position: Below Planned Assets
- Required: No
- Editable: No
- Default value: Not applicable
- Placeholder: Not applicable
- Options: Not applicable
- Validation: Not applicable
- Related controls: Task detail
- Notes: Main work-order data section.

### Task compliance

- Label: Task compliance
- Type: Field/column
- Position: Lower task detail area
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Task description, Compliance date
- Notes: Arrow from work-order section indicates relationship.

## 6. Tables / Lists

The notebook presents field groups but does not explicitly define table headers versus record detail fields.

### Emmsuite activity details

| Column Order | Field |
|-------------:|--------|
| 1 | Record No. |
| 2 | Aircraft No. |
| 3 | Data Imported Date |
| 4 | Closing Date |

### Planned Assets

| Column Order | Field |
|-------------:|--------|
| 1 | Asset |
| 2 | Description |
| 3 | Serial Num |
| 4 | CM Item |

### Work Order Details

| Column Order | Field |
|-------------:|--------|
| 1 | Work Order |
| 2 | Description |
| 3 | Status |
| 4 | Asset |
| 5 | Asset Description |
| 6 | Serial No. |
| 7 | CM Item |
| 8 | Work type |
| 9 | PM |
| 10 | PM Desc |
| 11 | Created By |
| 12 | Closure / cancelled Date |
| 13 | Closed By |

### Task detail

| Column Order | Field |
|-------------:|--------|
| 1 | Task compliance |
| 2 | Task description |
| 3 | Compliance date |
| 4 | Technician |
| 5 | Technician name |
| 6 | Log description |

## 7. Navigation

Source: Work Order Details
Target: Task detail
Trigger: Arrow shown from the work-order area
Relationship: Parent/detail relationship
Confidence: Inferred

## 8. User Interactions

No explicit buttons or interactive actions are shown.

The only explicit relationship is the arrow from Work Order Details to the lower task detail area.

## 9. Visual/Layout Instructions

- Preserve the three numbered sections and their vertical order.
- Keep the Work Order Details section below Planned Assets.
- Keep task details below the work-order fields.
- Preserve the arrow relationship visually or structurally.
- Maintain the broad horizontal field grouping.
- Do not add controls, buttons, filters, or actions not shown.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Provide a Consolidated Report page.
- Display Emmsuite activity details.
- Display Planned Assets.
- Display Work Order Details.
- Display task-compliance detail associated with the work order.
- Preserve the field ordering shown in each section.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Three numbered sections are present.
- All major section labels are visible.
- Work Order Details has a lower task detail area.
- The arrow relationship is explicitly drawn.

### Inferred / Unclear

- Exact spelling of the heading may be `CONSOLIDATED REPORT`; use this normalized capitalization based on the visible heading.
- Whether sections are tables or record details is not explicitly specified.
- Exact meaning of `PM` and `CM Item` is not specified.
- The arrow is interpreted as a work-order-to-task-detail relationship.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `IMG_F7563BD4-FFF8-4CAB-A403-63EFE4DDE927.jpeg`

### Confidence

Overall extraction confidence:
- Medium-High

### Potential OCR/Handwriting Issues

- `Emmsuite` is preserved as written.
- `Closure / cancelled Date` is a best-effort reading of the handwritten phrase.
- `Task compliance` is clearly visible but its exact intended data type is not specified.
