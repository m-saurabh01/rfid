# Reports / FSC

## 1. Page Purpose

This reference defines a **Reports** area centered on an **FSC (Flight Servicing Certificate)** report. The report is based on an aircraft/aircraft tail number and includes aircraft, engine, scheduled servicing, mission/armament, last servicing, flight acceptance, and snag history information.

The three notebook images are treated as one continuous Reports specification.

## 2. Overall Layout

### Top-level Reports area

- Heading: **Reports**
- First report selector: `FSC [Flight Servicing Certificate]`
- The report is based on `A/C (Aircraft tail no.)`.
- An `[AC tail no]` control/selection is shown.
- A `[Generate Report]` action appears to the right.
- A report header area then shows:
  - `A/C: <Aircraft>`
  - `Generated on : <date/time>`
  - `FSC`

### Report sections

The report then proceeds vertically through numbered sections:

1. Aircraft
2. Engine
3. Next Scheduled Servicing (Major)
4. Mission / Armament Loading Certificate
5. Type of last servicing
6. Flight Acceptance
7. Snag History
8. All Repetitive Snag
9. All Serious Snag
10. Replenishment / Meter Readings

The notebook separately shows a **Due List** after section 10.

## 3. Page Hierarchy

```text
Page
└── Reports
    ├── FSC [Flight Servicing Certificate]
    │   ├── Based on A/C (Aircraft tail no.)
    │   ├── [AC tail no]
    │   └── [Generate Report]
    ├── Report header
    │   ├── A/C: <Aircraft>
    │   └── Generated on: <date/time>
    ├── FSC
    ├── 1. Aircraft
    ├── 2. Engine
    ├── 3. Next Scheduled Servicing (Major)
    ├── 4. Mission / Armament Loading Certificate
    ├── 5. Type of last servicing
    ├── 6. Flight Acceptance
    ├── 7. Snag History
    ├── 8. All Repetitive Snag
    ├── 9. All Serious Snag
    ├── 10. Replenishment / Meter Readings
    └── Due List
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Page heading | heading | Reports | Top | No | |
| 2 | Report type | selector/label | FSC [Flight Servicing Certificate] | Top area | Unknown | |
| 3 | Basis label | label | Based on A/C (Aircraft tail no.) | Below FSC | No | |
| 4 | Aircraft tail selector | field/control | [AC tail no] | Left/center below basis | Unknown | |
| 5 | Generate Report | button/action | [Generate Report] | Right of aircraft selector | No | |
| 6 | Report identifier | label | Rep | Below generation controls | No | |
| 7 | Aircraft | field/label | A/C: <Aircraft> | Report header | Unknown | Placeholder-like notation is handwritten |
| 8 | Generated timestamp | field/label | Generated on: <date/time> | Report header | No | |
| 9 | FSC title | heading | FSC | Centered below report header | No | |
| 10 | Aircraft section | section | Aircraft | Section 1 | No | |
| 11 | Aircraft model | field/label | Model | Section 1 | Unknown | |
| 12 | Aircraft variant | field/label | Variant | Section 1 | Unknown | |
| 13 | Flight hours | field/label | Af Hr | Section 1 | Unknown | |
| 14 | Landings | field/label | Landings | Section 1 | Unknown | |
| 15 | Engine section | section | Engine | Section 2 | No | |
| 16 | Engine ST No. | field/label | Engine ST no. | Section 2 | Unknown | |
| 17 | Position | field/label | Position | Section 2 | Unknown | |
| 18 | ENG/APU/OPS HRS | field/label | ENG/APU/OPS HRS | Section 2 | Unknown | |
| 19 | ENG/APU/MSA STARTS | field/label | ENG/APU/MSA STARTS | Section 2 | Unknown | |
| 20 | Next servicing due | field/label | Next servicing Due | Section 2 | Unknown | |
| 21 | Remaining | field/label | Remaining | Section 2 | Unknown | |
| 22 | Next Scheduled Servicing | section | Next Scheduled Servicing (Major) | Section 3 | No | |
| 23 | Last servicing done | field/column | Last servicing Done | Section 3 | Unknown | |
| 24 | Part # | field/column | Part# | Section 3 | Unknown | |
| 25 | SL No. | field/column | SL No. | Section 3 | Unknown | |
| 26 | PM/Job plan description | field/column | PM/Jobplan Description | Section 3 | Unknown | |
| 27 | Worktype | field/column | Worktype | Section 3 | Unknown | |
| 28 | Complied at | field/column | Complied at | Section 3 | Unknown | |
| 29 | Complied date | field/column | Complied date | Section 3 | Unknown | |
| 30 | Next servicing due | field/column | Next Servicing due | Section 3(ii) | Unknown | |
| 31 | Part# | field/column | Part# | Section 3(ii) | Unknown | |
| 32 | SL No. | field/column | SL No. | Section 3(ii) | Unknown | |
| 33 | PM/Jobplan description | field/column | PM/Jobplan description | Section 3(ii) | Unknown | |
| 34 | WorkType | field/column | WorkType | Section 3(ii) | Unknown | |
| 35 | Due at | field/column | Due at | Section 3(ii) | Unknown | |
| 36 | Due date | field/column | due date | Section 3(ii) | Unknown | |
| 37 | Mission / Armament Loading Certificate | section | MISSION / ARMAMENT LOADING CERTIFICATE | Section 4 | No | |
| 38 | Station | field/column | Station | Section 4 | Unknown | |
| 39 | Position | field/column | Position | Section 4 | Unknown | |
| 40 | Role Eqpt Part | field/column | Role Eqpt Part | Section 4 | Unknown | |
| 41 | Role Eqpt SR No. | field/column | Role Eqpt SR No. | Section 4 | Unknown | |
| 42 | ARMT CIG | field/column | ARMT CIG | Section 4 | Unknown | |
| 43 | ARMT Description | field/column | ARMT Description | Section 4 | Unknown | |
| 44 | MFG Date | field/column | MFG Date | Section 4 | Unknown | |
| 45 | Load Qty | field/column | Load Qty | Section 4 | Unknown | |
| 46 | Serial No. | field/column | Serial No. | Section 4 | Unknown | |
| 47 | Lot No. | field/column | Lot No. | Section 4 | Unknown | |
| 48 | Remarks | field/column | Remarks | Section 4 | Unknown | |
| 49 | Type of last servicing | section | TYPE OF LAST SERVICING | Section 5 | No | |
| 50 | Workorder No. | field/column | Workorder No. | Section 5 | Unknown | |
| 51 | WorkType | field/column | WorkType | Section 5 | Unknown | |
| 52 | Work Description | field/column | Work Description | Section 5 | Unknown | |
| 53 | Name of Tradesmen | field/column | Name of Tradesmen | Section 5 | Unknown | |
| 54 | Maintenance/complaint details | field/column | Maintenance/complaint details | Section 5 | Unknown | |
| 55 | Flight Acceptance | section | FLIGHT ACCEPTANCE | Section 6 | No | |
| 56 | Caution/SPL info | field/column | Caution/SPL info | Section 6 | Unknown | |
| 57 | Pilot Remarks | field/column | Pilot Remarks | Section 6 | Unknown | |
| 58 | Service Id | field/column | Service Id | Section 6 | Unknown | |
| 59 | Rank | field/column | Rank | Section 6 | Unknown | |
| 60 | Name | field/column | Name | Section 6 | Unknown | |
| 61 | Sign | field/column | Sign | Section 6 | Unknown | |
| 62 | Date/time | field/column | Date/time | Section 6 | Unknown | |
| 63 | Snag History | section | SNAG HISTORY | Section 7 | No | |
| 64 | Snag No. | field/column | Snag No. | Section 7 | Unknown | |
| 65 | Reported Date/time | field/column | Reported Date/time | Section 7 | Unknown | |
| 66 | Description | field/column | Description | Section 7 | Unknown | |
| 67 | Rectification | field/column | Rectification | Section 7 | Unknown | |
| 68 | Category | field/column | Category | Section 7 | Unknown | |
| 69 | Work completed & certified | field/column | Work completed & certified | Section 7 | Unknown | |
| 70 | Trade | field/column | Trade | Section 7 | Unknown | |
| 71 | Name | field/column | Name | Section 7 | Unknown | |
| 72 | Work inspected & passed | field/column | Work inspected & passed | Section 7 | Unknown | |
| 73 | Supervisor name | field/column | Supervisor name | Section 7 | Unknown | |
| 74 | Closure date & time | field/column | Closure date & time | Section 7 | Unknown | |
| 75 | All Repetitive Snag | section | All Repetitive Snag | Section 8 | No | |
| 76 | All Serious Snag | section | All Serious Snag | Section 9 | No | |
| 77 | Replenishment / Meter Readings | section | Replenishment / Meter Readings | Section 10 | No | |
| 78 | Meter | field/column | Meter | Section 10 | Unknown | |
| 79 | Position | field/column | Position | Section 10 | Unknown | |
| 80 | Value | field/column | Value | Section 10 | Unknown | |
| 81 | Due List | section | Due List | Below section 10 | No | |
| 82 | Asset No. | field/column | Asset No. | Due List | Unknown | |
| 83 | Remaining Hrs | field/column | Remaining Hrs | Due List | Unknown | |
| 84 | Remaining within days | field/column | Remaining within days | Due List | Unknown | |
| 85 | Remaining within values | field/column | Remaining within values | Due List | Unknown | |
| 86 | Report Type | field/column | Report Type | Due List | Unknown | |
| 87 | Generated Date Time (by) | field/column | Generated Date Time (by) | Bottom | Unknown | |
| 88 | Log | button/action | [log] | Bottom-right | No | |

## 5. Exact Field Details

### Aircraft tail selector

- Label: [AC tail no]
- Type: Selection/input control
- Position: Below `Based on A/C (Aircraft tail no.)`
- Required: Unknown
- Editable: Yes/Unknown
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: Not specified in sketch
- Validation: Not specified in sketch
- Related controls: Generate Report
- Notes: Exact control type is unclear.

### Generate Report

- Label: Generate Report
- Type: Button/action
- Position: Right of the aircraft selection area
- Required: No
- Editable: No
- Default value: Not specified in sketch
- Placeholder: Not specified in sketch
- Options: None
- Validation: Not specified in sketch
- Related controls: A/C tail selection
- Notes: Explicitly bracketed in the sketch.

### Aircraft

- Label: A/C: <Aircraft>
- Type: Report field
- Position: Report header, left
- Required: No
- Editable: No
- Default value: Not specified
- Placeholder: `<Aircraft>` is shown as a symbolic value
- Options: None
- Validation: None
- Related controls: Report generation
- Notes: Treat as generated report metadata.

### Generated on

- Label: Generated on : <date/time>
- Type: Report metadata
- Position: Report header, right of aircraft metadata
- Required: No
- Editable: No
- Default value: Generated timestamp
- Placeholder: `<date/time>`
- Options: None
- Validation: None
- Related controls: Generate Report
- Notes: Preserve the timestamp concept.

## 6. Tables / Lists

The notebook specifies numerous report data groups. They should retain the handwritten column order within each group.

### Section 1 — Aircraft

| Column Order | Column |
|-------------:|--------|
| 1 | Aircraft |
| 2 | Model |
| 3 | Variant |
| 4 | Af Hr |
| 5 | Landings |

### Section 2 — Engine

| Column Order | Column |
|-------------:|--------|
| 1 | Engine ST no. |
| 2 | Position |
| 3 | ENG/APU/OPS HRS |
| 4 | ENG/APU/MSA STARTS |
| 5 | Next servicing Due |
| 6 | Remaining |

### Section 3(i) — Last servicing done

| Column Order | Column |
|-------------:|--------|
| 1 | Last servicing Done |
| 2 | Part# |
| 3 | SL No. |
| 4 | PM/Jobplan Description |
| 5 | Worktype |
| 6 | Complied at |
| 7 | Complied date |

### Section 3(ii) — Next servicing due

| Column Order | Column |
|-------------:|--------|
| 1 | Next Servicing due |
| 2 | Part# |
| 3 | SL No. |
| 4 | PM/Jobplan description |
| 5 | WorkType |
| 6 | Due at |
| 7 | due date |

### Section 4 — Mission / Armament Loading Certificate

| Column Order | Column |
|-------------:|--------|
| 1 | Station |
| 2 | Position |
| 3 | Role Eqpt Part |
| 4 | Role Eqpt SR No. |
| 5 | ARMT CIG |
| 6 | ARMT Description |
| 7 | MFG Date |
| 8 | Load Qty |
| 9 | Serial No. |
| 10 | Lot No. |
| 11 | Remarks |

### Section 5 — Type of last servicing

| Column Order | Column |
|-------------:|--------|
| 1 | Workorder No. |
| 2 | WorkType |
| 3 | Work Description |
| 4 | Name of Tradesmen |
| 5 | Maintenance/complaint details |

### Section 6 — Flight Acceptance

| Column Order | Column |
|--------:|--------|
| 1 | Caution/SPL info |
| 2 | Pilot Remarks |
| 3 | Service Id |
| 4 | Rank |
| 5 | Name |
| 6 | Sign |
| 7 | Date/time |

### Section 7 — Snag History

| Column Order | Column |
|-------------:|--------|
| 1 | Snag No. |
| 2 | Reported Date/time |
| 3 | Description |
| 4 | Rectification |
| 5 | Category |
| 6 | Work completed & certified |
| 7 | Trade |
| 8 | Name |
| 9 | Work inspected & passed |
| 10 | Supervisor name |
| 11 | Closure date & time |

### Section 10 — Replenishment / Meter Readings

| Column Order | Column |
|-------------:|--------|
| 1 | Meter |
| 2 | Position |
| 3 | Value |

### Due List

| Column Order | Column |
|-------------:|--------|
| 1 | Asset No. |
| 2 | Remaining Hrs |
| 3 | Remaining within days |
| 4 | Remaining within values |
| 5 | Report Type |
| 6 | Generated Date Time (by) |

Sections 8 and 9 only specify their section names. The notebook does not specify their columns.

## 7. Navigation

Source: Reports
Target: FSC report
Trigger: Selecting/using `FSC [Flight Servicing Certificate]`
Relationship: Report type selection
Confidence: High

Source: FSC report setup
Target: Generated FSC report
Trigger: `[Generate Report]`
Relationship: Generates report based on selected aircraft tail number
Confidence: High

## 8. User Interactions

- Select/enter aircraft tail number.
- Generate report.
- Review report sections.
- Access the `log` action shown near the Due List.

No edit workflow for report contents is specified.

## 9. Visual/Layout Instructions

- Keep `Reports` as the top heading.
- Keep FSC report selection above the generated report.
- Keep aircraft-tail selection on the left/center and Generate Report on the right.
- Keep report metadata above the `FSC` report heading.
- Preserve numbered section order from 1 through 10.
- Keep section 8 and section 9 as separate headings even though their internal columns are not specified.
- Keep Due List below Replenishment / Meter Readings.
- Preserve broad horizontal grouping of fields.
- Do not collapse all report sections into a single invented table.
- Do not invent colors, tabs, filters, pagination, or export controls.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Provide Reports.
- Provide FSC / Flight Servicing Certificate report selection.
- Allow the report to be based on A/C aircraft tail number.
- Provide Generate Report.
- Display generated aircraft and generation timestamp metadata.
- Display sections 1–10 in the shown order.
- Display the specified fields within each section.
- Display a Due List after section 10.
- Provide the shown `log` action.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Reports and FSC are explicit.
- Aircraft tail number is the report basis.
- Generate Report is explicit.
- Sections 1–10 are explicitly numbered/named.
- Due List is explicitly shown.
- Flight Acceptance and Snag History are separate sections.
- All Repetitive Snag and All Serious Snag are separate sections.

### Inferred / Unclear

- `Rep` appears to be a short report marker/label; exact meaning is unclear.
- `Af Hr` likely means aircraft hours, but this is not expanded in the notebook and should not be renamed.
- Exact UI control types are not specified.
- Exact report pagination/printing behavior is not specified.
- The purpose of `[log]` is unclear beyond being an explicit action.
- Columns for sections 8 and 9 are not specified.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `IMG_D0F60A27-B41D-41D3-8948-F1DB899A5A95.jpeg`
- Continuation: `IMG_879E716B-74F8-4C20-B084-2B623395F66D.jpeg`
- Continuation: `IMG_652E9A0E-0FFA-4FE5-AC5A-1C9427269BF3.jpeg`

### Confidence

Overall extraction confidence:
- Medium-High

### Potential OCR/Handwriting Issues

- `ENG/APU/MSA STARTS` is preserved exactly; the acronym is not expanded.
- `ARMT CIG` may be specialized terminology; preserve it exactly.
- `PM/Jobplan` and `PM/Job plan` appear with slight spacing differences in different rows; preserve the visible terminology.
- `Caution/SPL info` is preserved.
- `Work completed & certified` and `Work inspected & passed` are preserved.
