# Meter Compliance / Asset Install-Remove / Arming-De-Arming

## 1. Page Purpose

This reference contains three related areas:

1. **Meter compliance**
2. **Asset install/remove**
3. **ARMING / DE-ARMING**

The notebook presents these as sequential sections on the same page/reference.

## 2. Overall Layout

- Section `n4 → Meter compliance` appears first.
- It contains work-order and meter information.
- Section `n5 → Asset Install/remove` follows.
- It contains work-order, asset, position, CM item, status, and install/remove information.
- Section `n6 → ARMING / DE-ARMING` follows.
- It contains work order, hard point, station number, armament position, build item, armament item/tag number, description, part, serial number, lot number, quantities, remarks, status, and loaded/unloaded-by information.

## 3. Page Hierarchy

```text
Page
├── n4 → Meter compliance
│   ├── Work order
│   ├── Asset Desc.
│   ├── Meter
│   ├── Meter Description
│   ├── UOM
│   ├── Initial Value
│   ├── Final Value
│   ├── Part
│   ├── Build Item
│   ├── Reading Date
│   ├── Updated By
│   └── Updated date
├── n5 → Asset Install/remove
│   ├── Workorder
│   ├── Jobtype
│   ├── Item
│   ├── LCN
│   ├── Build Item
│   ├── Asset
│   ├── Position
│   ├── CM item
│   ├── Updated date
│   ├── Install/Remove By
│   ├── Created By
│   └── Status
└── n6 → ARMING / DE-ARMING
    ├── Workorder
    ├── Hard point
    ├── Station No.
    ├── Armament Position
    ├── Build item
    ├── Armament item/tag No.
    ├── Description
    ├── Part
    ├── Serial No.
    ├── Lot No.
    ├── Current quantity
    ├── Load qty
    ├── Unload qty
    ├── Remarks
    ├── Status
    └── Loaded/Unloaded By
```

## 4. UI Elements

| Order | Element | Type | Label/Text | Position | Editable | Notes |
|------:|---------|------|------------|----------|----------|-------|
| 1 | Meter compliance | section | n4 → Meter compliance | Top | No | |
| 2 | Work order | field/column | Work order | Section 4, first row, left | Unknown | |
| 3 | Asset Desc. | field/column | Asset Desc. | First row | Unknown | |
| 4 | Meter | field/column | Meter | First row | Unknown | |
| 5 | Meter Description | field/column | Meter Description | First row | Unknown | |
| 6 | UOM | field/column | UOM | First row, right | Unknown | |
| 7 | Initial Value | field/column | Initial Value | Second row, left | Unknown | |
| 8 | Final Value | field/column | Final Value | Second row, center | Unknown | |
| 9 | Part | field/column | Part | Second row | Unknown | |
| 10 | Build Item | field/column | Build Item | Second row, right | Unknown | |
| 11 | Reading Date | field/column | Reading Date | Third row, left | Unknown | |
| 12 | Updated By | field/column | Updated By | Third row, center | Unknown | |
| 13 | Updated date | field/column | Updated date | Third row, right | Unknown | |
| 14 | Asset Install/remove | section | n5 → Asset Install/remove | Below meter compliance | No | |
| 15 | Workorder | field/column | Workorder | First row | Unknown | |
| 16 | Jobtype | field/column | Jobtype | First row | Unknown | |
| 17 | Item | field/column | Item | First row | Unknown | |
| 18 | LCN | field/column | LCN | First row | Unknown | |
| 19 | Build Item | field/column | Build Item | First row, right | Unknown | |
| 20 | Asset | field/column | Asset | Second row, left | Unknown | |
| 21 | Position | field/column | Position | Second row | Unknown | |
| 22 | CM item | field/column | CM item | Second row | Unknown | |
| 23 | Updated date | field/column | Updated date | Second row, right | Unknown | |
| 24 | Install/Remove By | field/column | Install/Remove By | Third row, left | Unknown | |
| 25 | Created By | field/column | Created By | Third row, center | Unknown | |
| 26 | Status | field/column | Status | Third row, right | Unknown | |
| 27 | ARMING / DE-ARMING | section | n6 → ARMING / DE-ARMING | Below section 5 | No | |
| 28 | Workorder | field/column | Workorder | First row | Unknown | |
| 29 | Hard point | field/column | Hard point | First row | Unknown | |
| 30 | Station No. | field/column | Station No. | First row | Unknown | |
| 31 | Armament Position | field/column | Armament Position | First row, right | Unknown | |
| 32 | Build item | field/column | Build item | Second row | Unknown | |
| 33 | Armament item/tag No. | field/column | Armament item/tag No. | Second row, left | Unknown | |
| 34 | Description | field/column | Description | Second row, center | Unknown | |
| 35 | Part | field/column | Part | Second row | Unknown | |
| 36 | Serial No. | field/column | Serial No. | Second row, right | Unknown | |
| 37 | Lot No. | field/column | Lot No. | Third row, left | Unknown | |
| 38 | Current quantity | field/column | Current quantity | Third row, center | Unknown | |
| 39 | Load qty | field/column | Load qty | Third row, right | Unknown | |
| 40 | Unload qty | field/column | Unload qty | Fourth row, left | Unknown | |
| 41 | Remarks | field/column | Remarks | Fourth row, center | Unknown | |
| 42 | Status | field/column | Status | Fourth row, right | Unknown | |
| 43 | Loaded/Unloaded By | field/column | Loaded/Unloaded By | Fourth row, far right/lower | Unknown | |

## 5. Exact Field Details

### Meter compliance

- Label: Meter compliance
- Type: Section/data group
- Position: Top
- Required: No
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: None shown
- Notes: Contains initial/final meter values and update metadata.

### Initial Value

- Label: Initial Value
- Type: Field/column
- Position: Second row of Meter compliance
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Final Value
- Notes: Paired with Final Value.

### Install/Remove By

- Label: Install/Remove By
- Type: Field/column
- Position: Third row of Asset Install/remove
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Created By, Status
- Notes: Preserve slash and capitalization.

### Loaded/Unloaded By

- Label: Loaded/Unloaded By
- Type: Field/column
- Position: Bottom row of ARMING / DE-ARMING
- Required: Unknown
- Editable: Unknown
- Default value: Not specified
- Placeholder: Not specified
- Options: Not specified
- Validation: Not specified
- Related controls: Load qty, Unload qty, Status
- Notes: Explicitly represents who performed the loading/unloading.

## 6. Tables / Lists

The notebook presents each numbered area as a field/data group. No explicit table/list title or row behavior is shown.

### Meter compliance

| Column Order | Field |
|-------------:|--------|
| 1 | Work order |
| 2 | Asset Desc. |
| 3 | Meter |
| 4 | Meter Description |
| 5 | UOM |
| 6 | Initial Value |
| 7 | Final Value |
| 8 | Part |
| 9 | Build Item |
| 10 | Reading Date |
| 11 | Updated By |
| 12 | Updated date |

### Asset Install/remove

| Column Order | Field |
|-------------:|--------|
| 1 | Workorder |
| 2 | Jobtype |
| 3 | Item |
| 4 | LCN |
| 5 | Build Item |
| 6 | Asset |
| 7 | Position |
| 8 | CM item |
| 9 | Updated date |
| 10 | Install/Remove By |
| 11 | Created By |
| 12 | Status |

### ARMING / DE-ARMING

| Column Order | Field |
|-------------:|--------|
| 1 | Workorder |
| 2 | Hard point |
| 3 | Station No. |
| 4 | Armament Position |
| 5 | Build item |
| 6 | Armament item/tag No. |
| 7 | Description |
| 8 | Part |
| 9 | Serial No. |
| 10 | Lot No. |
| 11 | Current quantity |
| 12 | Load qty |
| 13 | Unload qty |
| 14 | Remarks |
| 15 | Status |
| 16 | Loaded/Unloaded By |

## 7. Navigation

No explicit navigation arrow is shown in this reference.

## 8. User Interactions

No explicit buttons/actions are shown.

The sections appear to represent information/data associated with their respective processes.

## 9. Visual/Layout Instructions

- Preserve section order: Meter compliance → Asset Install/remove → ARMING / DE-ARMING.
- Keep the broad horizontal arrangement of fields.
- Do not convert the three groups into unrelated pages.
- Preserve the capitalization and punctuation of labels.
- No styling/color requirements are shown.
- No buttons should be added because none are drawn.

## 10. Responsive/Layout Behavior

Responsive behavior is not specified in the notebook.

## 11. Functional Requirements Extracted From Sketch

- Provide a Meter compliance section with all twelve fields.
- Provide an Asset Install/remove section with all twelve fields.
- Provide an ARMING / DE-ARMING section with all sixteen fields.
- Preserve their relative order and grouping.

## 12. Ambiguities and Assumptions

### Confirmed From Sketch

- Section numbers n4, n5, n6 are shown.
- The three section names are explicit.
- Field labels are visible.

### Inferred / Unclear

- Exact input/display types are not specified.
- No required/optional information is shown.
- Whether the sections are tables or detail forms is not explicit.
- `LCN`, `CIG`, and similar domain abbreviations are not expanded.

## 13. Implementation Agent Instructions

Build the page according to this specification and preserve the visual hierarchy and ordering shown in the original notebook sketch.

Do not redesign the page.

Do not add functionality that is not specified.

Do not rename visible labels without a clear reason.

When a requirement is marked [UNCLEAR] or [INFERRED], implement the most conservative interpretation and do not introduce additional UI.

## 14. Source Traceability

### Source Image

- Image: `IMG_743E4D47-4AD7-467D-A6C0-398B5D2E21C2.jpeg`

### Confidence

Overall extraction confidence:
- High

### Potential OCR/Handwriting Issues

- `ARMING / DE-ARMING` is clear.
- `Armament item/tag No.` is a best-effort reading of the handwritten label.
- `Loaded/Unloaded By` is preserved exactly.
